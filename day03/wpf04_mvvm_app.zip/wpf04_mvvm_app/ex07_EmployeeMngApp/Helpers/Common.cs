﻿namespace ex07_EmployeeMngApp.Helpers
{
    public class Common
    {
        public static readonly string CONNSTRING = "Data Source=127.0.0.1;"+
                                                    "Initial Catalog=EMS;"+
                                                    "Persist Security Info=True;"+
                                                    "User ID=ems_user;" +
                                                    "Encrypt=False;"+
                                                    "Password=ems_p@ss";
    }
}
