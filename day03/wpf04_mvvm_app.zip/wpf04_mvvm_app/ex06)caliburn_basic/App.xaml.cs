﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace ex06_caliburn_basic
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public App() 
        {
            //InitializeComponent(); // Bootstrapper를 Application에 연결 
        }
    }

}
